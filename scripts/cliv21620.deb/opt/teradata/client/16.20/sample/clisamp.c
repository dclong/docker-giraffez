/************************************************************************
*   TITLE:        CLISAMP - CLIV2 Sample Application Program 16.10.00.01
*
*   Copyright 1987-2017 by Teradata Corporation.  All rights reserved.
*
*   DATABASE:     dbc
*
*   TABLE:        sessioninfo
*
*   INPUT PARMS:  None
*
*   OUTPUT:       Clisamp.dat
*
*   DESCRIPTION:  Retrieves rows from the sessioninfo table and
*                 writes them to a file.  This is done with the
*                 following steps:
*                 .  Initialize dbcarea
*                 .  Set desired options
*                 .  Connect and logon to DBC
*                 .  Fetch results of connect
*                 .  Discard results of connect by closing logon
*                    request
*                 .  Submit request to select rows from table
*                 .  Fetch results of the request and write to
*                    file
*                 .  Discard results of connect by closing
*                    request
*                 .  Logoff and disconnect from DBC
*                 .  Clean up and exit program
*                 This program is described in more detail in
*                 chapter 1 of the CLI Version 2 Manual.
*
*   COMMENTS:     The logon string in the program will have to be
*                 edited to represent a valid userid and password
*                 at a local site.
*
*                 For more information about using CLIV2, refer
*                 to the CLI Version 2 Manual.
*
*   HISTORY  F.1  87JAN12  DAA   DCR3075 SAMPLE PROGRAM FOR CLIV2
*            F.2  87JAN22  DAA   DR9022 TO SHIP SAMPLE PROGRAM.
*            F.3  87FEB24  DAA   DR9389 FIX ERROR RECOVERY
*            F.4  87FEB27  DAA   DR9323 FIX OF FORMATTING ROUTINE
*            F.5  87Mar09  DAA   DR9508 Add DBCHCLN on exit
*            F.6  87Mar17  DAA   DR9508 Add DBCHCLN on exit
*            F.7  87May18  DAA   DR9474 Add Logon success check
*            F.8  87May22  DAA   DR10087 Fix the bar character
*            F.9  88Jan25  DRP   DR11874 Fix the bar character
*            F.10 88Jan28  WHY   DR11926 (MR# fe87-18102a0)
*            F.11 88Feb26  DRP   DR12119 and DR12118 Fix for 3.1
*            F.12 88Apr27  HEIDI DR11442 coded new clisamp
*            F.13 88May27  WHY   DR12758 CLI manual name change
*           G0_00 88Jul25  SN    Created for Release G.0
*           G0_01 89Aug29  HEIDI DR17703 changed response mode to 'R'
*           G0_02 91Jan05  DJL   DCR5366 Tandem interface
*           G0_03 91Jun03  HEIDI DR17703 changed printf to fputc()
*           G0_04 91Jun04  HEIDI DR22193 Added copyright notice
*           H0_00 94Jun02  JAE   DR29062 Removed give_msg for confirm logoff.
*           H0_01 94Jun14  TL1   explicit cast on line 243 to avoid warning
*                                message.
*           H3_00 96Feb15  JAE   Changed version to H3_00.
*
*     04.00.00.01 JAE      1996Jun28 DR36785 Version number change. 
*     04.06.01.00 CSG      2001May25 DR55267 64 bit support, print version no. 
*     04.07.00.00 cc151010 2002Oct04 DR64667 Update documentation for sample.
*     04.07.00.01 CSG      2002Oct15 DR64797 Provide clisamp.c on Windows.
*     04.08.00.00 mg180007 2004Oct26 DR91125 Version number change
*     04.08.01.00 mg180007 2005Jun06 DR88148 Minor updates
*     12.00.00.11 fs185009 2006Nov29 DR108852 version change from 4.09.x to 12.0.x
*     13.00.00.00 mg180007 2008Jan09 DR117140 copyright update
*     13.10.00.00 kl185018 2010Jan11 DR133468 copyright update
*     14.10.00.00 hs186016 2012Apr16 CLAC-29536 fix incorrect parsing logon string
*     15.00.00.00 kl185018 2013May24 CLAC-30909 copyright update & Version change
*     15.00.00.01 kl185018 2014Jan15 CLAC-31729 copyright update
*     15.10.00.00 mg180007 2014Apr28 CLAC-32368 version change
*     16.00.00.00 bh185000 2016Nov26 CLIWS-3837 Prints out detail error message
*     16.10.00.00 hs186016 2017Apr26 CLIWS-6585 Fix regression from CLIWS-3837
*     16.10.00.01 vt186023 2017Jun20 CLIWS-6591 Changes to display the CLIv2 build version.
*   NOTES:        Please keep lines <= 65 characters long.
*                 Please avoid using tabs.
****************************************************************/

#include <stdio.h>          /* standard "C" include files */
#include <string.h>
#include <stdlib.h>        

#include <coptypes.h>       /* Teradata include files */
#include <coperr.h>
#include <dbcarea.h>
#include <parcel.h>
#include <dbchqep.h>        /* CLIWS-6591 */

#define CONNECTED     0
#define NOT_CONNECTED 1
#define OK            0
#define STOP          1
#define FAILED       -1
#define ERR_BUF_LEN   1024

struct DBCAREA dbc;         /* see dbcarea.h for definition of */
                            /* structure */
char   cnta[4];
char   CLIBuildVersion[32];  /* CLIWS-6591 */ 

#define CLISAMPFILE "CLISAMP.DAT"
FILE   *fp, *fopen();

#ifdef WIN32
  __declspec(dllimport) char   COPCLIVersion[];
  __declspec(dllimport) char   COPMTDPVersion[];
  __declspec(dllimport) char   COPMOSIosVersion[];
  __declspec(dllimport) char   COPMOSIDEPVersion[];
  __declspec(dllimport) char   OSERRVersion[];
#else
  extern char   COPCLIVersion[]; 
  extern char   COPMTDPVersion[]; 
  extern char   COPMOSIosVersion[]; 
  extern char   COPMOSIDEPVersion[]; 
  extern char   OSERRVersion[];
#endif

/* CLIWS-6585 --> */
#ifdef __cplusplus
extern "C" {
#endif
#ifdef WIN32
char * __stdcall terasso_get_terasso_version(void);
char * __stdcall OsGetCOPTDGSSVersion(void);
#else
char * terasso_get_terasso_version(void);
char * OsGetCOPTDGSSVersion(void);
#endif
#ifdef __cplusplus
}
#endif
/* <-- CLIWS-6585 */

int fetch_cli_version (char *ver, size_t size); /* CLIWS-6591 */ 

/***************************************************************/
/*  WRITE_OUTPUT -- formats output and writes to file          */
/***************************************************************/
write_output(dataptr, length)
char *dataptr;
Int32 length;
{
    Int16    j;              /* pointer for actual char output   */
    Int16    k;              /* counter                          */
    Int16    strsize;        /* length of string                 */
    char *tmpptr;            /* temp pointer to string           */

    tmpptr = dataptr;  strsize = length;
    while (strsize > 0)
    {
        j = (strsize < 80) ? strsize : 80;
        for (k = 0; k < j; k++, tmpptr++)
            fputc(*tmpptr,fp);
        fprintf(fp,"\n");
        strsize -= j;
    }
    return(0);
} /**end write_output**/

/***************************************************************/
/* WRITE_ERROR -- Prints error message that is located in      */
/*                the response buffer--Error or Failure Parcel */
/***************************************************************/
write_error(parcel)
char *parcel;
{
    int i;
    struct CliFailureType *Error_Fail = (struct CliFailureType *) parcel;
    printf("%d : ", Error_Fail->Code);
    for(i=0; i < (int)Error_Fail->Length; i++)
        printf("%c", Error_Fail->Msg[i]);
    printf("\n");
    return(0);
} /**end write_error**/


/***************************************************************/
/*  OPEN_FILE -- Opens file where data will be written         */
/*               if unable to open, will exit                  */
/***************************************************************/
open_file()
{
    if((fp = fopen(CLISAMPFILE, "w")) == NULL)
    {
        printf("FAILURE -- could not open output file\n");
        exit(0);
    }
    return(0);
} /**end open_file**/


/***************************************************************/
/*  SET_OPTIONS -- sets cli options (record,field,indicator    */
/*                 mode; etc..)                                */
/*                 Sets size of buffers (request and response) */
/***************************************************************/
set_options()
{
    dbc.change_opts = 'Y';
    dbc.resp_mode = 'R';
    dbc.use_presence_bits = 'N';
    dbc.keep_resp = 'N';
    dbc.wait_across_crash = 'N';
    dbc.tell_about_crash = 'Y';
    dbc.loc_mode = 'Y';
    dbc.var_len_req = 'N';
    dbc.var_len_fetch = 'N';
    dbc.save_resp_buf = 'N';
    dbc.two_resp_bufs = 'N';
    dbc.ret_time = 'N';
    dbc.parcel_mode = 'Y';
    dbc.wait_for_resp = 'Y';
    dbc.req_proc_opt = 'E';
    dbc.dbcoMsgL = 0;
    dbc.dbciMsgP = malloc(ERR_BUF_LEN);
    if (dbc.dbciMsgP != NULL)
        dbc.dbciMsgM = ERR_BUF_LEN;
    else
        dbc.dbciMsgM = 0;
    return(0);
} /**end set_options**/


/***************************************************************/
/* EXITOUT -- If connected logs off session. Cleans up         */
/*            any used memory.                                 */
/***************************************************************/
exitout(status)
int status;
{
    Int32 result = EM_OK;
    if (status == CONNECTED)
    {
        printf("Logging off.\n");
        dbc.func = DBFDSC;
        DBCHCL(&result, cnta, &dbc);
        if(result != EM_OK)
        {
            if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
                printf("disconnect failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
            else
                printf("disconnect failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        }
    }
    DBCHCLN(&result, cnta);
    if(result != EM_OK)
    {
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("cleanup failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("cleanup failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
    }

    fclose(fp);
    exit(0);
} /**end exitout**/


/***************************************************************/
/* INITIALIZE_DBCAREA -- Sets default options (clispb.dat) in  */
/*                       dbcarea by calling DBCHINI()          */
/***************************************************************/
initialize_dbcarea()
{
    Int32 result = EM_OK;
    dbc.total_len = sizeof(struct DBCAREA);
    DBCHINI(&result, cnta, &dbc);
    if (result != EM_OK)
    {
        /* if we can't initialize, we can't go on, so exit */
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("init failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("init failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        exitout(NOT_CONNECTED);
    }
    return(0);
}  /**end initialize_dbcarea**/


/***************************************************************/
/* LOGON_TO_DBC -- Connects session and logs on to DBC         */
/*                 Fetches result of connection to check if    */
/*                 successful                                  */
/***************************************************************/
logon_to_dbc(logonstr)
char logonstr[];
{
    Int32 result = EM_OK;
    printf("Logging on to --->%s\n", logonstr);
    dbc.logon_ptr = logonstr;
    dbc.logon_len = (UInt32) strlen(logonstr);
    dbc.func = DBFCON;

    DBCHCL(&result, cnta, &dbc);
    if (result != EM_OK)  /*if connect fails exit*/
    {
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("connect failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("connect failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        exitout(NOT_CONNECTED);
    }
    return(0);
} /**end logon_to_dbc**/

/***************************************************************/
/* CLOSE_REQUEST -- Terminates and cleans up specified request */
/***************************************************************/
close_request(req_id, sess_id)
Int32 req_id, sess_id;
{
    Int32 result = EM_OK;
    dbc.i_sess_id = sess_id;
    dbc.i_req_id = req_id;
    dbc.func=DBFERQ;

    DBCHCL(&result, cnta, &dbc);
    if (result != EM_OK)
    {
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("end request failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("end request failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        exitout(CONNECTED);
    }
    return(0);
} /**end close_request**/


/***************************************************************/
/* OPEN_REQUEST -- Sends request to DBC                        */
/***************************************************************/
open_request(rqst)
char rqst[];
{
    Int32 result = EM_OK;

    /* set up for a new request */
    printf("submitting-->%s\n", rqst);
    dbc.req_ptr = rqst;
    dbc.req_len = (UInt32) strlen(rqst);
    dbc.func = DBFIRQ;

    DBCHCL(&result, cnta, &dbc);
    if (result != EM_OK)
    {
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("initiate request failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("initiate request failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        exitout(CONNECTED);
    }
    return(EM_OK);
} /**end open_request**/


/***************************************************************/
/* FETCH_REQUEST -- Fetches results of a specific request and  */
/*                  session from DBC.                          */
/***************************************************************/
fetch_request(request, session)
Int32 session, request;
{
    Int32 result = EM_OK;
    int status = OK;
    dbc.i_sess_id = session;
    dbc.i_req_id = request;
    dbc.func = DBFFET;

    /* fetch one parcel at a time until all parcels are used up  */
    /* or an error occurs */

    while (status == OK)
    {
        DBCHCL(&result, cnta, &dbc);
        if (result == REQEXHAUST)
            status = STOP;
        else if (result != EM_OK) 
            status = FAILED;
        else switch ((Int16) (dbc.fet_parcel_flavor))
        {
            case PclSUCCESS:                        /*Success Parcel*/
                printf("writing out to --> %s \n", CLISAMPFILE );
                break;
            case PclRECORD :                         /*Returned data */
                write_output(dbc.fet_data_ptr, dbc.fet_ret_data_len);
                break;
            case PclFAILURE :                        /*Failure parcel*/
            case PclERROR :                          /*Error parcel  */
                status = STOP;
                write_error(dbc.fet_data_ptr);
                exitout(CONNECTED);
                break;
        } /*switch*/
    } /*while*/
    if (status == FAILED)
    { 
        if ((dbc.dbciMsgP != NULL) && (dbc.dbcoMsgL != 0))
            printf("fetch failed -- %.*s\n", dbc.dbcoMsgL, dbc.dbciMsgP);
        else
            printf("fetch failed -- %.*s\n", dbc.msg_len, dbc.msg_text);
        exitout(CONNECTED);
    } /*if*/
    return(0);
} /**end fetch_request**/

/***************************************************************/

main(int argc, char **argv)
{
    char  psDefaultLogon[] = "dbc/systemfe,service";
    char  *psLogon;
    int   i;
    int   iLength = 0;

    psLogon = NULL;
    if (argc >= 2)
    {
        if (!strncmp(argv[1], "-h", 2))
        {
            printf ("clisamp logonstring(dbcname/username,password)\n");
            exit(1);
        }
        for (i = 1; i < argc; i++)
        {
            iLength += strlen(argv[i]);
        }
        psLogon = (char *)malloc(iLength + 1);
        if (psLogon != NULL)
        {
            memset(psLogon, 0, iLength+1);
            for (i = 1; i < argc; i++)
            {
                strcat(psLogon, argv[i]);
            }
        }
        else 
        {
            printf ("out of memory\n");
            exit(1);
        }
    }
    if (psLogon == NULL)
    {
        psLogon = psDefaultLogon;
    }

    /* CLIWS-6591 --> */
    if (fetch_cli_version(CLIBuildVersion, sizeof (CLIBuildVersion)) == 0)
    {
        printf("\nCLIv2   version is %s\n", CLIBuildVersion);
    }
    /* <-- CLIWS-6591 */
    else
    {
        printf("\nCLIv2   version is %s\n", COPCLIVersion);
    }
    printf("MTDP    version is %s\n",   COPMTDPVersion);
    printf("MOSIOS  version is %s\n",   COPMOSIosVersion);
    printf("MOSIDEP version is %s\n",   COPMOSIDEPVersion);
    printf("OSERR   version is %s\n", OSERRVersion);
    printf("TERAGSS version is %s\n", OsGetCOPTDGSSVersion());

    open_file();
    initialize_dbcarea();
    set_options();
    logon_to_dbc(psLogon);
    fetch_request(dbc.o_req_id, dbc.o_sess_id);
    close_request(dbc.o_req_id, dbc.o_sess_id);
    open_request("select * from dbc.sessioninfo;");
    fetch_request(dbc.o_req_id, dbc.o_sess_id);
    close_request(dbc.o_req_id, dbc.o_sess_id);
    exitout(CONNECTED);
} /**end main**/

/* CLIWS-6591 --> */
/****************************************************************/
/* FETCH_CLI_VERSION -- calls DBCHQE/QEPICL2R function to       */
/*                      fetch the CLIv2 BUILDVERSION.           */
/****************************************************************/
int fetch_cli_version (char *ver, size_t size)
{
    DBCHQEP query_params = {0,};
    char    dummy[4] = {0,};
    Int32   err_code ;

    if (ver == NULL || size < 2) /* Needed space for atleast one character */
    {
        printf ("fetch_cli_version: Error! Invalid args received.\n");
        return -1;
    }

    memset (ver, 0, size);
    query_params.qepLevel   = QEPLEVEL;
    query_params.qepItem    = QEPICL2R;
    query_params.qepRArea   = ver;
    query_params.qepRALen   = size;

    DBCHQE (&err_code, dummy, &query_params);
    if (err_code != EM_OK)
    {
        printf ("fetch_cli_version: Error! DBCHQE returned error code[%d].\n", err_code);
        return -2;
    }
    return 0;
}
/* <-- CLIWS-6591 */

