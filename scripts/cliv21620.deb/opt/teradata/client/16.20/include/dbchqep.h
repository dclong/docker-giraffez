#ifndef DBCHQEP_H
#define DBCHQEP_H
#define DBCHQEP_H_REV "16.20.00.00"
/*******************************************************************************
 *
 *
 *  WARNING: Because mosiif.h is shared and is used as a header
 *           file for mainframe SAS/C compiles under VM/CMS, the logical
 *           record length (i.e., line length) must not exceed 80
 *           characters.
 *-----------------------------------------------------------------------------*
 *                   <-- ( 8 0    c h a r a c t e r s) -->
 *******************************************************************************
 *  TITLE:       DBCHQEP.H ..  Interface file for CLIv2 Query       16.20.00.00
 *                             Environment function
 *
 *  Purpose      To contain interface information to invoke the
 *               CLIv2 Query Environment function
 *
 *  Copyright 1993-2017 by Teradata Corporation.  All rights reserved.
 *
 *  Description  This include file contains the interface definitions
 *               for the CLIv2 Query Environment function
 *
 * Revision    Date     DCR     DID      Comments
 * ----------- -------- ------- -------- --------------------------------------
 *       H0_00 04/26/93 DR27514 AFK      Coded
 *       H1_00 06/02/94 DR29459 AFK      Default Character Set
 *       HN_01 06/07/94 DR29459 AFK      Default Character Set
 *       H3_00 08/31/95 DR32294 JAE      NDM code merge into 5.3 CLI.
 * 04.00.00.01 07/12/96 DR36785 TH4      Version number change.
 * 04.02.00.00 09/05/97 DR36456 TH4      64KB row support.
 * 04.02.00.01 10/14/97 DR40693 JTH      CLI2 release info.
 * 04.04.00.00 05/15/98 DR41392 JTH      Common hdr for all platforms
 * 04.04.00.01 06/12/98 DR41392 DHF      Updated to add WIN32 also.
 * 04.04.00.02 06/29/98 DR41392 DHF      Updated for SunOS.
 * 04.04.00.03 08/11/98 DR43449 TH4      Fix the pointer to context area
 * 04.04.02.00 03/15/99 DR45173 TH4      New function for (V)AMP count.
 * 04.05.00.00 01/18/00 DR45724 CSG      CLI2 C++ safe
 * 04.05.00.01 03/03/00 DR48735 CSG      TDSP Support
 * 04.05.00.02 08/04/00 DR48823 ASG      OS/390 USS
 * 04.06.00.00 08/28/00 DR51432 TH4      UPSERT Support
 * 04.06.00.01 10/09/00 DR49674 CSG      Query-TDP release.
 * 04.06.00.02 12/04/00 DR52305 ASG      SSO
 * 04.06.00.00 01/17/01 DR52052 ASG      Support SSO
 * 04.06.00.01 03/07/01 DR54498 CSG      Revert macro QEPLEVEL for compatibility
 *                                       with existing applications
 * 04.06.01.00 05/25/01 DR55267 CSG      Native 64bit support
 * 04.06.01.01 11/05/01 DR58769 ASG      Support TWB operators with OS/390 C/C++
 * 04.06.02.00 04/01/02 DR59026 CSG      DR55267 mistyped qepTIdP[8] labels
 * 04.06.02.01 03/27/02 DR58353 CSG      CLI Sub second timing capability.
 * 04.06.02.02 03/28/02 DR60508 CSG      Add PerformUpdate feature support
 * 04.07.00.00 05/08/02 DR58369 CSG      Native 64 bit support to CLIv2 on HPUX
 * 04.07.00.01 05/18/02 DR58915 CSG      Native 64 bit support to CLIv2 on AIX
 * 04.07.00.02 06/06/02 DR59337 CSG      Port CLI to 64 Bit Windows XP.
 * 04.07.00.03 06/06/02 DR57320 CSG      Support Increased maximum response size
 * 04.07.00.04 06/17/02 DR61637 CSG      Support enlarged parcel usage.
 * 04.07.00.05 06/03/02 DR57583 ASG      LOB support
 * 04.07.00.06 08/22/02 DR52059 CSG      L10N support
 * 04.07.00.07 09/14/02 DR64073 CSG      Make TTU7.0 CLI bkward compatible with
 *                                       client applications
 * 04.07.01.00 01/20/03 DR66372 TH4      Change the maximum number of dbchqe
 * 04.07.01.01 02/11/03 DR65533 mg180007 IDC support
 * 04.07.01.02 03/31/03 DR60695 ASG      Cursor positioning.
 * 04.07.01.03 04/04/03 DR66712 mg180007 Data encryption.
 *                              ASG
 * 04.08.00.00 07/22/03 DR68511 mg180007 clean up defines, prototypes
 *                      DR68139          self-sufficient headers
 * 04.08.00.01 12/02/03 DR68838 ASG      array-ops support
 * 04.08.00.02 09/24/03 DR68835 ASG      APH / 1 MB Responses
 * 04.08.00.03 09/25/03 DR67666          Add support for Aggregate list
 *                                           support for charset query
 * 04.08.00.04 02/10/04 DR85431 ASG      Universalize headers
 * 04.08.00.05 02/10/04 DR58352 ASG      ESS
 * 04.08.00.06 03/19/04 DR69030 ASG      UDT
 * 04.08.00.07 04/06/04 DR86683 ASG      Avoid name collision w/ MF CLIv2
 * 04.08.00.08 03/17/04 DR68842 mg180007 TTU 8.0 Security
 * 04.08.00.09 06/24/05 DR94488 CSG      Port to HP-Itanium
 * 04.08.01.00 03/07/05 DR66632 ASG      Add support for DBS release info
 * 04.08.01.01 03/10/05 DR92655 ASG      Add support for default sess charset
 * 04.08.01.02 03/15/05 DR93457 ASG      Add support for relaxed call arguments
 * 04.08.01.03 03/30/05 DR91422 mg180007 HP_ALIGN pragma issue with aCC
 * 04.08.01.04 03/30/05 DR92059 ASG      Add support for CLIv2 and DBS limits
 * 04.08.01.05 04/21/05 DR93472 mg180007 added header revision info
 * 04.08.01.06 07/25/05 DR97391 ASG      Set QEPLEVEL to 5 for z/OS C/C++ apps
 * 04.08.01.07 08/28/05 DR97702 ASG      Fix alignment problem in 64-bit
 * 04.08.02.00 12/15/05 DR98024 bh185000 Support for MaxDecimalPrecision
 *                      DR98025 bh185000 Support for AGKR_option
 *                      DR98026 bh185000 Support for StatementInfo
 * 04.08.02.01 02/14/06 DR102061 ASG      reconfig for 80-byte lines
 * 04.08.02.02 05/17/06 DR103694 ASG      correct SQL limits ordering
 * 04.09.00.00 05/31/06 DR102528 bh185000 Support for Dynamic Result Sets
 * 04.09.00.01 06/07/06 DR103360 bh185000 Support for Query Banding
 * 04.09.00.02 06/08/06 DR103358 bh185000 Support for Mini Batch INS-SEL
 * 04.09.00.03 10/13/06 DR101287 mg180007 Support for Default Connection
 * 04.09.00.04 11/08/06 DR106757 ASG      Fixes to support IBM z/OS C/C++
 * 12.00.00.05 11/29/06 DR108852 fs185009 version change from 4.09.x to 12.0.x
 * 13.00.00.00 09/26/07 DR113468 bh185000 Support session NODE ID for ARC
 * 13.00.00.01 11/13/07 DR115326 bh185000 Support Trusted Lightweight Session
 * 13.00.00.02 11/20/07 DR115324 bh185000 Support LOB Loader Phase II
 * 13.00.00.03 12/05/07 DR108586 mg180007 GenerateCredentialFromLogon
 * 13.00.00.04 01/09/08 DR117140 mg180007 copyright update
 * 13.00.00.05 01/04/08 DR111599 fs185009 Add new query item for db access path
 * 13.01.00.00 12/09/08 DR123516 bh185000 Support StmtInfo UDT Transforms Off
 * 13.01.00.01 12/18/08 DR122304 bh185000 Support Trusted Sessions Security
 * 13.01.00.02 03/12/09 DR125340 kl185018 WS CLIv2 build for 32-bit programming
 *                                        model on HP-UX ia64
 * 13.10.00.02 06/23/09 DR133468 kl185018 Version change from 13.01 to 13.10
 * 14.00.00.00 02/14/11 DR121202 bh185000 Fix for Statement Independence
 * 14.00.00.01 09/09/11 CLAC-2657  bh185000 Support VMAP count query
 * 14.10.00.00 03/22/12 CLAC-28857 mg180007 Suport ESS level
 * 14.10.00.01 05/30/12 CLAC-29081 bh185000 Support Max. Deferred-by-Name
 * 14.10.00.02 01/06/13 CLAC-18937 hs186016 NW CLIv2 support for Mac OS X
 * 15.00.00.00 10/31/13 CLAC-31558 bh185000 Support JavaScript Object Notation
 * 15.00.00.01 11/14/13 CLAC-30554 hs186016 Support SLOB
 * 15.10.00.00 04/28/14 CLAC-32368 mg180007 version and copyright update
 * 16.00.00.00 03/05/15 CLAC-29115 bh185000 Support 1M byte response row
 * 16.00.00.01 04/08/15 CLAC-33135 bh185000 Support Unicode Pass Through
 * 16.00.00.02 10/15/15 CLAC-34037 bh185000 Additional support for 16MB message
 * 16.00.00.03 03/10/16 CLAC-34612 bh185000 Support Max Num Rec in Iterated Req
 * 16.20.00.00 12/06/17 CLIWS-6627 hs186016 Support Transform Group for Type
 ******************************************************************************/

/* DR85431 --> */
#if (defined(I370) || defined(IBM370))
#include "coptypes.h" /* DR68139 */
#else
#include <coptypes.h> /* DR68139 */
#endif
/* <-- DR85431 */

typedef struct _DBCHQEP
{
    unsigned char   qepLevel;        /* structure version # */
    unsigned char   qepItem;         /* requested item #    */
    unsigned short  qepTLen;         /* length of TDPID            H1_02*/
    /* DR55267: Native 64bit support         */
    /* DR58369: Native 64bit support on HPUX */
    /* DR58915: Native 64bit support for AIX */

#ifdef CLI_64BIT
    Int32	   qepConn;	    /* DR55267: Session  number        */
#else
    Int32	   qepTDP;	    /* DR55267: TDP name for 32 bit addressing*/
#define qepSess qepTDP              /* session number             H1_00*/
#define qepConn qepTDP              /* session number             HN_01*/
#endif /* CLI_64BIT */
    char            qepRsv1[4];      /* reserved: m/b 0 */
    unsigned short  qepRALen;        /* Return area length */
    unsigned short  qepRDLen;        /* Returned data length */
    /* DR55267: Native 64bit support         */
    /* DR58369: Native 64bit support on HPUX */
    /* DR58915: Native 64bit support for AIX */

#ifdef CLI_64BIT
    char            qepRArea4[4];    /* DR55267: reserved m/b 0  */
#else
    void*           qepRArea;        /* pointer to return area */
#endif /* CLI_64BIT */
    char            qepMLid[2];      /* DR52059, Msg Lang id   */
    unsigned short  qepMCid;         /* reserved: m/b 0 */
    /* DR55267: Native 64bit support         */
    /* DR58369: Native 64bit support on HPUX */
    /* DR58915: Native 64bit support for AIX */

#ifdef CLI_64BIT
    char            qepMCSP4[4];     /* reserved: m/b 0 */
    char            qepMsgP4[4];     /* reserved: m/b 0 */
#else
    char*           qepMCSP;         /* reserved: m/b 0 */
    char*           qepMsgP;         /* DR52059, ptr to msg buf*/
#endif /* CLI_64BIT */
    unsigned short  qepMsgM;         /* DR52059, msg area len */
    unsigned short  qepRMLen;        /* DR52059, CLI returned */
                                     /* message length        */
    unsigned short  qepRMRC;         /* DR52059, return code  */
                                     /* while building msg    */
    unsigned short  qepRC;           /* DR52059, return code  */
                                     /* while processing DBCHQE*/
    /* DR55267: Native 64bit support         */
    /* DR58369: Native 64bit support on HPUX */
    /* DR58915: Native 64bit support for AIX */

#ifdef CLI_64BIT
    char*           qepTIdP;     /* DR55267: TDP name for 64bit addressing */
                                 /* DR59026:DR55267 mistyped qepTIdP[8] labels*/
    void*           qepRaP;      /* DR55267: pointer to return area:64 bit */
    char*           qepMCSP;     /* reserved: m/b 0 */
    char*           qepMsgP;     /* DR52059, ptr to msg buf*/
#define qepTDP     qepTIdP       /* DR55267: qepTDP redefined for 64bit */
                                 /* DR59026:DR55267 mistyped qepTIdP[8] labels*/
#define qepRArea   qepRaP
#else
    char            qepTIdP8[8];     /* DR55267: reserved m/b 0 */
                         /* DR59026: DR55267 mistyped qepTIdP[8] labels*/
    char            qepRaP8[8];      /* reserved: m/b 0         */
    char            qepMCSP8[8];     /* reserved: m/b 0         */
    char            qepMsgP8[8];     /* reserved: m/b 0         */
#endif /* CLI_64BIT */
    int             qepRqst;         /* Message Release query   */
    int             qepToken;        /* DR67666,Add character   */
                                     /*         list query      */
} DBCHQEP;

/* Values for qepLevel */
#ifdef __MVS__                      /* DR97391 */
#define QEPLEVEL 5
#else
#define QEPLEVEL 1                  /* DR54498 */
#endif
#define QEPL64   4                  /* For 64bit addressing */

/* DR64073 , If applications need to use QEPLVL 1 and L10N support */
#define QEPL10NLVL1  1 | 0x80       /* DR52059 : Used only in N/W CLI */

/* DR64073 , If applications need to use QEPLVL 2 and L10N support */
#define QEPL10NLVL2  2 | 0x80       /* DR52059:  Used only in N/W CLI */

/* Values for qepItem  */
#define QEPIIID  1                  /* installation ID     */
#define QEPISC   2                  /* character set              H1_00*/
#define QEPIFTSM 3                  /* tx-semantics support       H1_02*/
#define QEPIFLCS 4                  /* lang-conformance support   H1_02*/
#define QEPIFUCR 5                  /* updatable cursor support   H1_02*/
#define QEPIFRFI 6                  /* referential integ. support H1_02*/
#define QEPIDTSM 7                  /* tx-semantics default       H1_02*/
#define QEP64K   8                  /* DR36456, 64KB row support       */
#define QEPICL2R 9                  /* DR40693 CL2 Release Info        */
#define QEPIDPF  10                 /* DR45173 (V)AMP count.           */
#define QEPISPF  10                 /* CLAC-2657 (V)AMP count          */
#define QEPIDMSS 11                 /* DR48735, MaxSegmentSize         */
#define QEPITDPR 12                 /* DR49674, For Mainframe Compatibility */
#define QEPIFSSO 13                 /* DR52052, SSO                    */
#define QEPISU   14                 /* DR52052, actual username        */
#define QEPIFUPS 15                 /* DR51432 UPSERT Support.         */
#define QEPIAOP  16                 /* DR68838 array-ops support       */
#define QEPIFMRG 17                 /* DR60508 Merge-Into  Support     */
#define QEPIFLOB 18                 /* DR57583  LOB support            */
#define QEPITPR  19                 /* DR58353 precision on timestamp  */
#define QEPIXRS  20                 /* DR57320 extended response sup.  */
#define QEPIEPU  21                 /* DR61637 enlarged parcel support */
#define QEPITMT  22                 /* ------- timestamp type support  */
#define QEPIUD   23                 /* DR65533 Identity Column Support */
#define QEPIASL  24                 /* ------- aggregate support list  */
#define QEPIRPO  25                 /* DR60695 cursor positioning sup. */
#define QEPIENC  26                 /* DR66712 data encryption         */
#define QEPIRMR  27                 /* Message Release Query           */
#define QEPIACS  28                 /* DR67666: character set info     */
#define QEPIESS  29                 /* DR58352: Enhanced Statement Status */
#define QEPIUDT  30                 /* DR69030: User-defined types     */
#define QEPIAPH  31                 /* DR68835: APH responses (DR86683)*/
#define QEPIALM  32                 /* DR68842: avail logon mechanisms */
#define QEPIDCS  33                 /* DR92655 server default char set */
#define QEPIDBR  34                 /* DR66632 DBS release info        */
#define QEPIC2L  35                 /* DR92059 CLIv2 limits            */
#define QEPISQL  36                 /* DR92059 SQL limits              */
#define QEPIRCA  37                 /* DR93457 relaxed call arguments  */
#define QEPISIS  38                 /* DR98026 statement info parecel  */
#define QEPIIDE  39                 /* DR98024 MaxDecimalPrecision     */
#define QEPIRID  40                 /* DR98025 ReturnIdentityData      */
#define QEPIDRS  41                 /* DR102528 DynamicResultSets      */
#define QEPIQBS  42                 /* DR103360 Query Banding          */
#define QEPIMIU  43                 /* DR103358 Merge-Into-Usage       */
#define QEPILEU  44                 /* DR103358 Logging-Errors-Usage   */
#define QEPIPD   45                 /* DR101287 Default Connection     */
#define QEPISCS  46                 /* DR111614 Session Character Set  */
#define QEPICCS  47                 /* DR111615 Column Correlation     */
#define QEPIUS   48                 /* DR113468 Utility Session ID     */
#define QEPIDAP  49                 /* DR111599 database access path   */
#define QEPITSS  50                 /* DR115326 Trusted Session        */
#define QEPILNS  51                 /* DR115324 LOB Loader Phase II    */
#define QEPITOU  52                 /* DR123516 UDT TransformsOff      */
#define QEPITRS  53                 /* DR122304 Trusted Session/Request*/
#define QEPIBI   54                 /* DR121202 FetchRowCount/Build Inf*/
#define QEPISES  55                 /* DR121202 Statement Independence */
#define QEPISSU  56                 /* CLAC-28857 ESS level/usage      */
#define QEPIILB  57                 /* CLAC-30554 SLOB                 */
#define QEPIUPT  58                 /* CLAC-33135 Unicode Pass Through */
#define QEPISRU  59                 /* Not Used, StmtInfo Request Usage*/
#define QEPISTT  60                 /* CLIWS-6627 Transform Group Type */
#define QEPIMAX  60                 /* Maximum query number            */

/* DR92059 -> */

                 /*---> DR67666 *//* DR68842 */
#if defined(WIN32) || defined(__APPLE__)       /* CLAC-18937 */
#pragma pack(push,1)
#elif defined(HPUX_IA64) || defined(HPUX_IA32) /* DR94488 */ /* DR125340 */
#pragma pack 1
#elif (defined(HPUX) && !defined(HP_ALIGN_ISSUE)) /* DR91422 */
#pragma HP_ALIGN NOPADDING PUSH
#elif defined(AIX)
#pragma options align=packed
#else
#pragma pack(1)
#endif

struct QEPCLLIMIT_ {
    UInt64            MaxRequestBytes;
    UInt64            MaxSegRequestBytes;
    UInt64            MaxUsingDataBytes;
    UInt64            MaxResponseBytes;
};
#define CLI_LIMITS_LEN       sizeof(struct QEPCLLIMIT_)

/* DR103694 -> */
struct QEPDBLIMIT_ {
    UInt64             MaxRowBytes;
    UInt64             MaxLobBytes;
    UInt32             MaxObjectNameChars;
    UInt32             MaxColinTbl;
    UInt32             MaxTblinSel;
    UInt32             MaxColinSel;
    UInt32             MaxColGrpBy;
    UInt32             MaxColOrdrBy;
    UInt32             MaxCharLiteralChars;
    UInt32             MaxBinLiteralChars;
    UInt32             MaxColBytes;
    UInt32             MaxCharChars;
    UInt32             MaxVarcharChars;
    UInt32             MaxGraphicChars;
    UInt32             MaxVargraphicChars;
    UInt32             MaxByteBytes;
    UInt32             MaxVarbyteBytes;
    UInt32             MaxDecimal;
    UInt32             MaxTimeScale;
    UInt32             MaxTimeStampScale;
    UInt32             MaxIntervalToSecondScale;
    UInt32             MaxFldsUsingRow;
    UInt32             MaxParamsInRequest;
    UInt32             MaxSPParams;
    UInt32             MaxDeferredByNameFileSpec; /* CLAC-29081 */
    UInt32             MaxRequestTextBytes;       /* CLAC-34037, CLAC-31558 */
    UInt64             MaxJSONBytes;              /* CLAC-31558 */
    UInt64             MaxAvailBytesInRespRow;    /* CLAC-29115 */
    UInt32             MaxNumRecInIteratedReq;    /* CLAC-34612,offset 128-131*/
};
#define SQL_LIMITS_LEN     sizeof(struct QEPDBLIMIT_)
#define BASE_LIMITS_LEN    104 /* CLAC-34612, from MaxRowBytes to MaxSPParams */
/* <- DR103694 */
/* <- DR92059 */


/* This structure can be use by the
   applications to retrieve info
   on avaialable character set names
   at the Server */

typedef struct QEPCSINFO_ {
       UInt32  qeracsTk; /* Token, !should not modified by application*/
       UInt16  qeracsNR; /* Number of character sets not returned */
       UInt16  qeracsNP; /* Number of character sets returned     */
       UInt16  qeracsLn; /* Length of each character set name     */
                         /* Variable part follows in QEPAREA      */
} QEPCSINFO;

/* DR68842 -> */
typedef struct QEPLMINFO_ {
       UInt32  qeralmTk; /* Token, !should not modified by application*/
       UInt16  qeralmNR; /* Number of mechanisms not returned */
       UInt16  qeralmNP; /* Number of mechanisms returned     */
       UInt16  qeralmLn; /* Length of each mechanism name plus flags     */
                         /* Variable part follows in QEPAREA      */
} QEPLMINFO;

typedef struct QEPLMITEM_ {
       char    mech_name[8];
       char    default_flag;   /* 'D' if default */
       char    generate_cred_from_logon; /* DR108586: 'Y' or 'N' */
       char    future_use[6];  /* reserved for future use and alignment */
} QEPLMITEM;
/* <- DR68842 */

#if defined(WIN32) || defined(__APPLE__)       /* CLAC-18937 */
#pragma pack(pop)
#elif defined(HPUX_IA64) || defined(HPUX_IA32) /* DR94488 */ /* DR125340 */
#pragma pack
#elif (defined(HPUX) && !defined(HP_ALIGN_ISSUE)) /* DR91422 */
#pragma HP_ALIGN POP
#elif defined(AIX)
#pragma options align=reset
#elif defined(__MVS__)     /* DR106757 */
#pragma pack(reset)        /* DR106757 */
#else
#pragma pack()
#endif
               /* DR67666 *<---*/

#ifndef NOPROT

/* DR85431 --> */
#if ((defined(I370) || defined(IBM370)) && !defined(__MVS__)) /* DR106757 */
#define LINKAGE __asm
#else
#define LINKAGE
#endif

#ifdef __cplusplus                 /* DR45724-> */
#ifdef __MVS__
extern "OS" {
#else
extern "C" {
#endif    /* <-DR45724 */
#endif

#ifdef WIN32 /* DR68511 */
    Int32   __stdcall DBCHQE  (Int32  *, char *, DBCHQEP *);
#else /* WIN32 */
LINKAGE Int32 DBCHQE(Int32 *, char *, DBCHQEP *);
#endif /* WIN32 */

#ifdef __cplusplus                         /* DR45724-> */
}
#endif /* __cplusplus */                   /* <-DR45724 */
#if defined(__MVS__) && !(defined(__cplusplus))
#pragma linkage(DBCHQE,OS)
#endif
/* <-- DR85431 */

#endif /* NOPROT */
#endif /* DBCHQEP_H */
