#ifndef MOSIIF_H
#define MOSIIF_H
#define MOSIIF_H_REV "16.20.00.04"
/*******************************************************************************
 *
 *  WARNING: Because mosiif.h is shared and is used as a header
 *           file for mainframe SAS/C compiles under VM/CMS, the logical
 *           record length (i.e., line length) must not exceed 80
 *           characters.
 *-----------------------------------------------------------------------------*
 *                   <-- ( 8 0    c h a r a c t e r s) -->
 *******************************************************************************
 *
 *  TITLE:       MOSIIF.H .. Micro Operating System Interface       16.20.00.04
 *                           type definitions for "C"
 *
 *  Copyright 1983-2018 by Teradata Corporation. All rights reserved.
 *  TERADATA CONFIDENTIAL AND TRADE SECRET.
 *
 *  Purpose      To contain the type definitions for calling MOSI from "C".
 *
 *  History
 *    D.1   86Nov10  KKL  Coded.
 *    F.1   86Nov10  DRP  DCR 3075 CLIV2 error codes
 *    F.2   87Jun01  KKL  DR 10404 added mosi routines def.
 *    F.3   87Jun01  DAA  DR 10404 added mosi routines def.
 *    F.4   87Jun05  DAA  DCR 3430 added Vax defs
 *    F.5   87Jul01  DAA  DCR 3430 Vax support
 *    F.6   87Aug05  DAA  DR 10465 fix OSI logoff problem
 *    F.7   87Aug03  DAA  DR 10553 fix bkgd. task interrupt
 *    F.8   88Mar09  DAA  DCR 4338 Async Logon
 *    F.9   88Mar09  DAA  DCR 4338 Async Logon
 *    F.10  88Mar09  DAA  DCR 4338 Async Logon
 *    F.11  88Mar24  KKL  DCR 3431 Add Protocol_XNS
 *    G0_01 88Sep09  KKL  DR 14025 Added routines defs
 *    G0_02 88Sep28  KKL  DR 14025 Fixed bad char
 *    G0_03 89Jan26  PMB  DCR 4937 Sun 386i workstation
 *    G0_04 92Jan29  BTA  ANSI C/Sun C conflict fixed
 *    G0_04 89Sep20  ECB  DR 15531 Fix for VAX, etc.
 *    G0_05 89Oct31  KKL  DCR4106  Support OS_MACOS
 *    G0_06 90May07  KBC  DR10675  Define all prototypes for MOSI
 *                                 internal functions
 *    G0_07 90Sep14  KXO           Revised for UNIX PORTING KIT
 *    G0_08 90Nov13  KBC  DR20832  Add OSERR external functions.
 *    G0_09 91Jan05  DJL  DCR5366  Tandem interface
 *    G0_10 91Jan23  DJL  DCR5366  Add ALLOCFAIL
 *    G0_11 91Jan11  KBC  DR20832  Fix OSSetCtl definition.
 *    G0_12 91Jan29  BUGS DCR4350  CBTEQ changes, original changes made
 *                                 by GLL on 90Feb22 and 90Nov08.
 *    G0_13 91Feb11  KBC  DCR5366  Fix missing end comment
 *    G0_14 91Feb19  BUGS DCR4350  Removed one #ifdef IBM370 cond
 *    G0_15 91Feb19  BUGS DCR4350  Added OS_MVS opsys type and ARCH_OS370
 *    G1_01 91Jul13  BTA  DCR5957  Added Support for MosiTSR
 *    G1_02 91Dec01  BGN  DCR6174  First revision for OS/2
 *    G1_03 91Dec31  KBC  DCR5966  Support for Windows WinCLIV2.DLL
 *    G1_04 92Jan22  JAE  DCR6003  Added ARCH_HP9000 for HP9000 Port.
 *    H0_00 93May20  SNT  DCR6711  Created for Release H.0
 *    H3_00 95Sep13  TH4  DR34047  Added the #ifndef XXXX #define XXXX.
 *    H3_01 96Mar08  SYY  DR35631  Merge WinCLI 3.0 changes into mainstream
 * 04.01.00.00 10Sep96 JAE DR35723 Parallel MTDP code merge.
 * 04.01.00.01 12Nov96 JAE DR38020 Changed ifdef name from MPRAS to SPINLOCK.
 * 04.01.00.02 13Nov96 JAE DR38077 Added OsSemGetval() declaration.
 * 04.02.00.00 JTH July97  dr40000 Code merge
 * 04.02.00.01 TH4 02Sep97 DR40372 Ported form Wcli311, logon takes too long.
 * 04.03.00.00 TH4 05Feb98 DR40973 Porting Parallel CLI to WinCLI.
 * 04.04.00.00 TH4 25Jun98 DR42948 Cleanup compiler warnings.
 * 04.05.00.00 CSG 19Nov99 DR47427 mosiif.h needs to add WIN32 compiler
 *                                 directive
 * 04.05.00.01 CSG 2000Jan18 DR45724 CLI2 C++ safe.
 * 04.06.00.00 CSG 2001Jan24 DR52054 Port CLI to HP-UX.
 * 04.06.00.01 CSG 2001Jan30 DR52055 Port CLI to AIX.
 * 04.06.01.00 CSG 2001May25 DR55267 Native 64bit support
 * 04.06.01.01 cc151010 2001Aug30 DR52050 Multi-threaded support.
 * 04.06.01.02 CSG      2001Oct31 DR58615 WinCLI fails when network supplies
 *             more than 32K bytes at one time
 * 04.06.02.00 cc151010 2002Feb04 DR59974 OsSetEx signature changed to support
 *            c++.
 * 04.06.02.01 CSG      2002Mar06 DR55126 Add logonsource info to sessiontbl
 * 04.06.02.02 CSG      2002Mar27 DR58353 CLI Sub second timing capability.
 * 04.06.02.03 CSG      2002May03 DR61529 ProcessId in the LogonSource column
 *                                        is -tive on Windows 98.
 * 04.06.02.04 CSG      2002May03 DR61244 Timestamp status flags are always set
 *                                        to 'O' on MP-RAS
 * 04.07.00.00 CSG      2002Jun06 DR59337 Port CLI to 64 Bit Windows XP
 *                                        Added OS_WIN64.
 * 04.07.00.01 CSG      2002Jun06 DR57320 Support increased response size.
 * 04.07.00.02 CSG      2002Jun06 DR61637 Support enlarged parcel usage.
 * 04.07.00.03 cc151010 2002Sep10 DR63674 Update RWLOCK_T structure.
 * 04.07.00.04 mg180007 2002Dec20 DR65345 Changed unsigned int to caddr_t in
 *                                        OsShmCheck definition
 * 04.07.01.00 mg180007 2003Feb05 DR66882 Define anomaly logging options
 * 04.07.01.01 mg180007 2003Feb07 DR61924 Fix OsShmAlloc/OsShmFree definition
 *                                        for Linux (where PMTDP isn't defined)
 *                                        Change return type of OsFree to void*
 * 04.07.01.02 mg180007 2003Apr14 DR66712 removed old encryption code
 * 04.08.00.00 mg180007 2003Jul22 DR68511 clean up defines, prototypes
 *                                DR68139 self-sufficient headers
 *                                DR68140 fix EXPENTRY definition
 * 04.08.00.01 BH185000 2003Oct20 DR67539 COP selection enhancement
 * 04.08.00.02 mg180007 2004Jan12 DR85369 Add OS_LINUX for BTEQ Linux support
 * 04.08.00.03 ASG      2004Feb26 DR85431 universalize headers
 * 04.08.00.04 CSG      2004Mar16 DR52058 UTF16 support
 * 04.08.00.05 mg180007 2004Jun08 DR87475 MPRAS relocation error
 * 04.08.00.06 BH185000 2004Jun05 DR84940 Multi-threaded CLI on UNIX
 * 04.08.00.07 ASG      2004Jun14 DR87725 Avoid name collision with BTEQ
 * 04.08.00.08 ASG      2004Jun25 DR87894 More accommodations for BTEQ
 * 04.08.00.09 BH185000 2004Dec06 DR67971 Support ip_format logon string
 * 04.08.01.00 mg180007 2005Feb14 DR92232 merge and update copyright year
 * 04.08.01.01 mg180007 2005Feb24 DR68882 More debug info on error
 * 04.08.01.02 mg180007 2005Apr04 DR94431 IP logon to V2R5
 * 04.08.01.03 mg180007 2005Apr21 DR93472 added header revision info
 * 04.08.01.04 bh185000 2005May02 DR92061 Remove unused Parallel MTDP code
 * 04.08.01.05 mg180007 2005May25 DR95277 Moved IPCOPNUM definition
 * 04.08.01.06 mg180007 2005Jun23 DR96390 abortive disconnect on reconnect
 * 04.08.01.07 mg180007 2005Jul27 DR67971 support multiple ports
 * 04.08.02.00 ASG      2006Feb14 DR102061 reconfig for 80-byte lines
 * 04.09.00.00 mg180007 2006Jul12 DR101287 support Default Connection
 * 12.00.00.01 fs185009 2006Nov29 DR108852 version change from 4.09.x to 12.0.x
 * 13.00.00.00 mg180007 2008Jan09 DR117140 copyright update
 * 13.00.00.01 fs185009 2008Jan15 DR107850 Add OsAnomlogInit
 * 13.00.00.02 fs185009 2008Feb04 DR105227 Add OsAnomlogSizeSet
 *                                        & OsAnomlogSizeChk
 * 13.00.00.03 fs185009 2008Feb04 DR103507 Add OsGetHostent
 * 13.00.00.04 fs185009 2008Apr28 DR121836 Add CLIMAXHOST
 * 13.00.00.05 mg180007 2008Nov10 DR127548 IPv6 phase 1 of 2
 * 13.01.00.00 mg180007 2009Jan19 DR120874 COP cache should use FQDN
 * 13.01.00.01 mg180007 2009Mar01 DR116309 increase dbcname length
 * 13.01.00.02 mg180007 2009Jun02 DR132411 IPv6 uses wrong interface
 * 13.10.00.02 kl185018 2009Jun23 DR133468 Version change from 13.01 to 13.10
 * 14.00.00.00 kl185018 2010Sep14 DR125356 Remove support for MP-RAS
 * 14.00.00.01 mg180007 2009Jul01 DR118581 HSN improvements
 * 14.00.00.02 bh185000 2010Dec10 DR100017 Remove unused MOSI functions
 * 14.00.00.03 mg180007 2010Dec21 DR118581 include time.h for struct timeval
 * 14.00.00.04 mg180007 2011Jan18 DR147868 change CLI_COPS default to 0
 * 14.00.00.05 mg180007 2011Jun21 DR151885 make CLI self-contained
 * 14.10.00.00 hg186016 2011Mar14 CLAC-6027 resolve undefined struct timeval
 * 14.10.00.01 mg180007 2012Jan30 CLAC-663 return TdWallet version info
 * 14.10.00.02 SE185013 2012Mar27 CLAC-29436 Switch to use HPUX 11.23
 *                                           Compiler for PA-RISC builds 
 * 14.10.00.03 mg180007 2012May10 CLAC-29355 fix logon_timeout
 * 14.10.00.04 hs186016 2013Jan06 CLAC-18937 NW CLIv2 support for Mac OS X
 * 14.10.00.05 hs186016 2013Jan08 CLAC-30419 Fix crashes when log file grows big
 * 14.10.00.06 hs186016 2013Jan08 CLAC-30419 Revert 14.10.00.05, add comments
 * 15.10.00.00 mg180007 2014Apr28 CLAC-32368 version and copyright update
 * 15.10.00.01 hs186016 2014May30 CLAC-29137 Split COPANOMLOG files for threads
 * 15.10.00.02 hs186016 2014Jun20 CLAC-32705 include <sys/time.h> for Linux
 * 15.10.00.03 hs186016 2014Jun24 CLAC-29137 Split COPANOMLOG files for threads
 * 15.10.00.04 hs186016 2014Sep12 CLAC-32071 Support User Selectable directory
 * 16.00.00.00 hs186016 2015Feb10 CLAC-33175 Fix function name mangling
 * 16.00.00.01 mg180007 2015Apr09 CLAC-29671 Added OsGetOsInfoString()
 * 16.00.00.02 hs186016 2015Jun19 CLAC-30122 Support Multiple IP addr per COPn
 * 16.00.00.03 hs186016 2017Feb09 CLIWS-6492 Reduce compile warning messages
 * 16.10.00.00 vt186023 2017Jul18 CLIWS-6509 Support in-memory COPANOMLOG   
 * 16.20.00.00 vt186023 2017Sep27 CLIWS-6743 Increase session limit 
 *                                           (POLL_SETSIZE) to 2048 for Unix
 * 16.20.00.01 vt186023 2017Nov06 CLIWS-6772 Add SESSIONLOG facility  
 * 16.20.00.02 hs186016 2017Dec27 CLIWS-6770 Remove session limit per process
 *                                           for non-Windows
 * 16.20.00.03 hs186016 2018Jan30 CLIWS-6790 Remove internal data structures
 *                                           from mosiif.h
 * 16.20.00.04 hs186016 2018Apr04 CLIWS-6938 Fix crash due to out of memory
 ******************************************************************************/

/* DR85431 --> */
#if (defined(I370) || defined(IBM370))
#include "coptypes.h" /* DR68139 */
#include <signal.h>
#else
#include <coptypes.h> /* DR68139 */
#endif
/* <-- DR85431 */
#ifndef EXPENTRY
#ifdef WIN32
#define EXPENTRY __stdcall /* DR68139, DR68140, DR86451 */
#else  /* WIN32 */
#define EXPENTRY
#endif /* WIN32 */
#endif /* ifndef EXPENTRY */

/*
   *** WARNING *** WARNING *** WARNING *** WARNING *** WARNING *** WARNING ***

   The following #ifdef is needed by BTEQ and various utilities, both MF and NW.
   When the PARALLEL_MTDP environment variable is eliminated in TW 8.1, pro-
   vision must be made for ensuring that a suitable replacement is implemented
   for the special case below.
   LX_CLI is also added for Linux since Linux does not define PARALLEL_MTDP in
   the compile line. Search for "DR87725 -->" for the changes.
*/

/* DR87725 --> */ /* CLAC-18937 */
#if defined(PARALLEL_MTDP) || defined(LX_CLI) || defined(__APPLE__)
/* DR84940 begin */
#ifndef WIN32
#include <pthread.h>
#endif
/* DR84940 end */
#endif /* <-- DR87725 */

#if (!defined(WIN32))     /* CLAC-18937, 32705 */
#include <sys/time.h> /* DR118581 for struct timeval */
#elif (!defined(_WINSOCKAPI_) && !defined(_WINSOCK2API_))
#include <winsock2.h>  /* CLAC-6027 for struct timeval */
#endif

#include <stdio.h> /* CLAC-29137 */

#ifndef min /* DR68882 */
#define min(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif

/*=================================*/
/* Machine architecture types      */
/*=================================*/

#define ARCH_M68K       1  /* DR68511: no longer used */
#define ARCH_INTEL      2
#define ARCH_SPARC      3  /* Sun RISC type machine */
#define ARCH_VAX        4  /* DR68511: no longer used */
#define ARCH_UTS370     5  /* DR68511: no longer used */
#define ARCH_TANDEM     6  /* DR68511: no longer used */
#define ARCH_OS370      7  /* DR68511: no longer used */
#define ARCH_HP9000     8  /* DCR6003 */ /* DR68511: no longer used */

/*=====================================*/
/* Following are possible opsys code   */
/*=====================================*/

#define OS_UNIX5        1
#define OS_PCDOS        2
#define OS_VMS          3
#define OS_MACOS        4
#define OS_VM           5  /* DR 15531 */
#define OS_GUARDIAN     6
#define OS_MVS          7  /* DCR 4350 */
#define OS_OS2          12 /* leave room for others */
#define OS_WIN32        13 /* DCR 7013, MS Windows 32 bit OS's */
#define OS_WIN64        14 /* DR59337, MS Windows 64 bit OS's  */
#define OS_LINUX        15 /* DR85369 */

/*========================================================*/
/* Following are possible connect sequence (conseq) codes */
/*========================================================*/

#define PROTOCOL_OSI    1
#define PROTOCOL_TCP    2
#define PROTOCOL_XLN    3
#define PROTOCOL_MAP    4
#define PROTOCOL_DNA    5
#define PROTOCOL_SRV    6
#define PROTOCOL_XNS    7

/*================*/
/*       misc     */
/*================*/

#define SECONDS         1
#define MILLISECONDS    2
#define DATAGRAM        1
#define VIRTUALCIRCUIT  2
#define NODATAGRAM      3
/* DR68511 */
                             /* -> DR 55126              */
/* CLAC-29671: The maximum username length on Windows is lmcons.h:UNLEN. */
/*             But this value can't change for backward-compatibility.   */
#define MAXLOGINNAMELEN  92   /* Maximum system username  */ /* DR52058 */
    /* DR87725 */
#define MAXFILENAMELEN  256  /* Maximum path length      */
                             /* DR 55126              <- */
#define  DBCNAMLEN   70  /* DR116309: =DNS_MAX_LABEL_BUFFER_LENGTH+port */
#define  DOMAINLEN  262  /* DR120874, DR116309: FQDN+port     */

#define MAX_CONCURRENT_SOCKETS 9 /* DR118581 */

/* DR 58353 : Constants used to rectify Conversion Error  */
#define ConvCorrectionMicro   1048576/1000000
#define ConvCorrectionMilli   1024/1000

#define  IPCOPNUM   (-8) /* DR67971, DR95277 */

#define  CLIMAXHOST 1026 /* DR121836: = NI_MAXHOST + 1 */


/***************************************************************/
/*                   STRUCTURE DEFINITIONS                     */
/***************************************************************/
/*==================================*/
/* configuration block definition   */
/*==================================*/

typedef struct confBlk
{
    int       conf_code;
    int       MOSI_st_num;
    string_t  version;
    int       opsys;
    int       architecture;
    string_t  ser_num;
    int       gmt_diff;
    int       bits_byte;
    int       bits_addr_unit;
    int       protocol;
    int       conseq;

}    cnfblk_t, *cnfbp_t;


/*=============================================================*/
/*       used by mosi internally                               */
/*       for Microsoft Network Session Layer Interface         */
/*=============================================================*/

struct SCBType
{
    Byte    command;   /* A one byte field containing the command code */
                       /* The high order bit of the command byte is set*/
                       /* to indicate asynchronous operation of the    */
                       /* command (on commands which support the       */
                       /* asynchronous mode).                          */

    Byte    err;       /* It contains either an error or a 'command    */
                       /* pending' flag if the command has not yet     */
                       /* completed.  This field should not be polled  */
                       /* for command completion * (see done).         */

    Byte    vcid;      /* It contains the virtual circuit identifier.  */
                       /* This value is returned by the call and listen*/
                       /* commands. The value must be filled in for the*/
                       /* send and receive commands.                   */

    Byte    num;       /* used with datagram support.                  */
                       /* It has a domain of 1 to 254.                 */

    Int32   baddr;     /* contains the address of the data to be       */
                       /* transferred. This field is in double word    */
                       /* format (DD segment: offset).                 */

    Int16   length;    /* It contains the length, in bytes, of the data*/
                       /* to be transfered(buffer len)                 */

    char    rname[16]; /* remote network name.All 16 bytes must be use */

    char    lname[16]; /* local network name. All 16 bytes must be used*/

    Byte    rto;       /* It contains the receive timeout for a virtual*/
                       /* circuit. This is set by a call or listen     */
                       /* command, & holds for the life of the circuit.*/
                       /* A zero results in use of a transport-depend- */
                       /* ent default, Otherwise it specifies the time */
                       /* in 500ms. increments.                        */

    Byte    sto;       /* It contains the send timeout for a virtual   */
                       /* circuit. This is set by a call or listen     */
                       /* command, & holds for the life of the circuit.*/
                       /* A zero results in use of a transport-depend- */
                       /* ent default, Otherwise it specifies the time */
                       /* in 500ms. increments.                        */

    Int32   async;     /* it contains the address of the asynchronous  */
                       /* notification routine.  This field is in      */
                       /* double-word format (DD segment:offset).      */
                       /* If this field is zero and the asynchronous   */
                       /* form of the command is used, then the "done" */
                       /* must be polled to determine completion.      */
                       /* The routine is called at interrupt time with */
                       /* interrupts masked off.                       */
                       /* To return, issue an IRET instruction.        */

    Byte    res1;      /* reserved field. Must be zero.                */

    Byte    done;      /* It contains 0xff if the command is pending.  */
                       /* Any other value indicates the command        */
                       /* completed or there was an error.             */

    Byte    res2[14];  /* reserved fields. Must be zero                */
};

/*=================================================*/
/* Locking Structures - 05112001 cc151010 DR 52050 */
/* START of new code                               */
/*=================================================*/

/* This struct is used generally and supports multi-thread CLI */

typedef struct {
#ifdef WIN32                /* DR40973 */
    HANDLE  semid;
#else
    int     semid;      /* Set Identifier */
#endif
    int     semnum;     /* Number within set */
    int     inuse;      /* Flag value */
} sema_t;

/* 05/11/2001 cc151010 DR 52050 */
/* add these lock defs for read/write locks in sockets */

/* DR63674 Change lock structures */
/* DR84940 */
typedef struct RWLOCK {
/* DR87725 --> */ /* CLAC-18937 */
#if defined(PARALLEL_MTDP) || defined(LX_CLI) || defined(__APPLE__)
#ifdef WIN32
    sema_t          *lock;              /* semaphore for lock */
    sema_t          *access;            /* access semaphore */
#else
    pthread_mutex_t lock;
    pthread_mutex_t access;
#endif
#endif /* <-- DR87725 */
    int             iReaders;           /* number of active readers */
} RWLOCK_T;

#if defined(SPINLOCK) && !defined(lint)
typedef UInt32 OsLock_t;
#else
/* Standard system V locking with semaphores */
typedef sema_t OsLock_t;
#endif

/*
 * Locking operations
 */

/*
 * These macros define OsShmAlloc and OsShmFree
 */
#define OsShmAlloc(size, error)    OsAlloc(size, error)
#define OsShmFree(location, error) OsFree((storid_t) location, error)

/*=================================================*/
/* Locking Structures - 05112001 cc151010 DR 52050 */
/* END of new code                                 */
/*=================================================*/

/*=======================*/
/* Possible scb commands */
/*=======================*/

#define CANCEL           0x35
#define RESET            0x32
#define STATUS           0x33
#define ADDNAME          0x30
#define DELETENAME       0x31
#define CALL             0x10
#define LISTEN           0x11
#define HANGUP           0x12
#define SEND             0x14
#define RECEIVE          0x95                  /* asynchronous */
#define NAMESTATUS       0x34
#define SENDDATAGRAM     0x20
#define RECEIVEDATAGRAM  0xa1                  /* asynchronous */
#define INTVECT          0x2a


/***************************************************************/
/*                                                             */
/* 87Aug03 DAA DR10553 to add support for disabling Control-C  */
/* handler and checking stdin                                  */
/*                                                             */
/***************************************************************/

/*=======================*/
/* IO_type specification */
/*=======================*/

#define IO_FILE          1
#define IO_TTY           2

/*=======================*/
/* IO_code specification */
/*=======================*/

#if (defined(I370) || defined(IBM370))    /* DR85431 */
#define IO_STDIN      0
#define IO_STDOUT     1
#define IO_STDERROUT  2
#else
#define IO_STDIN      1
#define IO_STDOUT     2
#define IO_STDERROUT  4
#endif
#define IO_STDERRIN      3
#define IO_TERMIN        5
#define IO_TERMOUT       6
#define IO_PRINT         7
#define MAX_IO_CODE      8

/*=========================*/
/* IO_status specification */
/*=========================*/

#define IO_STS_NOAVAIL   0
#define IO_STS_NOCONN    1
#define IO_STS_CONNECT   2
#define IO_STS_OPEN      3

/*===============================*/
/* exception class specification */
/*===============================*/

#define EXPT_HUP         1    /* hangup (modem control)     */
#define EXPT_INT         2    /* break (control-C)          */
#define EXPT_BREAK       2    /* for backward compatibility */
#define EXPT_QUIT        3    /* forced exit                */
#define EXPT_ILL         4    /* illegal instruction        */
#define EXPT_TRAP        5    /* trace trap                 */
#define EXPT_IOT         6    /* IOT instruction            */
#define EXPT_EMT         7    /* EMT instruction            */
#define EXPT_FPE         8    /* Floating point exception   */
#define EXPT_KILL        9    /* forced exit                */
#define EXPT_BUS        10    /* bus error                  */
#define EXPT_SEGV       11    /* segment violation          */
#define EXPT_SYS        12    /* bad system call argument   */
#define EXPT_PIPE       13    /* broken pipe                */
#define EXPT_ALARM      14    /* alarm                      */
#define EXPT_TERM       15    /* terminate process          */
#define EXPT_USR1       16    /* user defined signal        */
#define EXPT_USR2       17    /* user defined               */
#define EXPT_CLD        18    /* death of a child           */
#define EXPT_PWR        19    /* power fail                 */

extern char COPMOSIProtocol[];
extern char COPMOSIDEPVersion[];

#if (!(defined(I370) || (defined(IBM370))))   /* DR85431 */
extern char COPMOSIosVersion[];
extern char OSERRVersion[];
extern char COPOsEncryptVersion[];
extern char COPMTDPVersion[];
extern char COPCLIVersion[];

#ifndef _HANDLER
#define _HANDLER HANDLER
typedef void (*HANDLER)();
#endif
#endif

#if (defined(I370) || defined(IBM370))    /* DR85431 */
#define  EM_BUSY        150      /* MF CLIv2 - session is busy */
#define  KBD_INT        160      /* MF CLIv2 - keyboard interrupt */
#define  IBM_DBC_CRASH  286      /* MF CLIv2 - server crash */
#endif

/************************************************************/
/*         Following are MOSI routines in MOSIDEP.C         */
/************************************************************/
/* DR68511 --> */

#ifdef __cplusplus
extern "C" {
#endif
    storid_t EXPENTRY OsAlloc(unsigned, errpt_t);
    Int32    EXPENTRY OsDelay(unsigned, int, errpt_t);
    void*    EXPENTRY OsFree(storid_t, errpt_t);
    Int32    EXPENTRY OsGetIOA(Int32, Int32 *, char *, systag_t, errpt_t);
    Int32    EXPENTRY OsGetLoginSource(UInt32 *, char *, char *);
    UInt32   EXPENTRY OsGetPerfTim(SAVETIME *, Boolean, Int32 *, Int16 *);
    Int32    EXPENTRY OsGtTim(errpt_t);
    char *   EXPENTRY OsGetCOPMOSIDEPVersion(void);
    int      EXPENTRY inet_parse
       (char *, unsigned int *, int *); /* DR94431, DR67971 */

    /* DR118581 -> */
    struct timeval *OsGetDBSMaxElapsed(char *, char *, error_t *);
    int             kshuffle(int*, unsigned int, int*, unsigned int);
    /* <- DR118581 */
#ifdef __cplusplus
}
#endif
/* <-- DR68511 */

/************************************************************/
/*        Following are MOSI routines in MOSI[OS].C         */
/************************************************************/
/* DR87725 --> */ /* CLAC-18937 */
#if defined(PARALLEL_MTDP) || defined(LX_CLI) || defined(__APPLE__)
#ifdef WIN32
typedef void * OsRegion_t;             /* DR52050 */
#else
typedef pthread_mutex_t OsRegion_t;    /* DR84940 */
#endif

/* locking operations */
#ifdef WIN32
void volatile EXPENTRY OsCriticalBegin(OsRegion_t *);       /* DR 52050 */
void     EXPENTRY OsCriticalEnd(OsRegion_t *);              /* DR 52050 */
int      EXPENTRY OsInitCritical(OsRegion_t *, errpt_t);    /* DR 52050 */
int      EXPENTRY OsDeInitCritical(OsRegion_t *, errpt_t);  /* DR 52050 */
#else
int      OsLockGlobals(pthread_mutex_t *);                  /* DR 84940 */
int      OsUnlockGlobals(pthread_mutex_t *);                /* DR 84940 */
int      OsCriticalInit(pthread_mutex_t *);                 /* DR 84940 */
int      OsCriticalBegin(pthread_mutex_t *);                /* DR 84940 */
int      OsCriticalEnd(pthread_mutex_t *);                  /* DR 84940 */
#endif
Int32    EXPENTRY OsAtomicIncrement(Int32 * var);           /* DR 52050 */
Int32    EXPENTRY OsAtomicDecrement(Int32 * var);           /* DR 52050 */
Int32    EXPENTRY OsAtomicRead(Int32 * var);                /* DR 52050 */
Int32    EXPENTRY OsAtomicWrite(Int32 * var, Int32 val);    /* DR 52050 */
Int16    OsStartReadLock(RWLOCK_T *RWLock,errpt_t error);   /* DR 52050 */
Int16    OsStopReadLock(RWLOCK_T *RWLock,errpt_t error);    /* DR 52050 */
Int16    OsStartWriteLock(RWLOCK_T *RWLock,errpt_t error);  /* DR 52050 */
Int16    OsStopWriteLock(RWLOCK_T *RWLock,errpt_t error);   /* DR 52050 */
Int16    OsGetOsInfoString(char *, UInt16 *);             /* CLAC-29671 */
#endif /* <-- DR87725 */

int      ka_send_all();       /* 06192001 cc151010 DR 52050 Fix warning */
int      iport_parse(char *);                               /* DR 67971 */

#ifdef __cplusplus
extern "C" {
#endif
    /* dr40000 */
    void     EXPENTRY OsGtSys(cnfbp_t, errpt_t);
    void     EXPENTRY OsWake(void);
#ifdef __cplusplus
}
#endif

#ifdef WIN32 /* DR47427, DR68511 */
char *   EXPENTRY OsGetCOPMOSIosVersion(void);     /* CLAC-32071, 33175 */
char *   EXPENTRY OsGetCOPMOSIProtocol(void);      /* CLAC-32071, 33175 */
Int16    EXPENTRY OsHangup(systag_t, errpt_t);
Int16    EXPENTRY OsAbtHangup(systag_t, errpt_t); /* DR 96390*/
Int32    EXPENTRY OsRecv(systag_t, UInt32, storid_t, UInt32, errpt_t);
 /* DR58615 *//* DR57320 */
Int16    EXPENTRY OsReset(errpt_t);
Int32    EXPENTRY OsSend(systag_t, UInt32, storid_t, UInt32, errpt_t);
 /* DR61637 */
Int32    EXPENTRY RestoreCLIEnv (void);
Int32    EXPENTRY SaveCLIEnv (void);
#else /* WIN32 */
#ifdef __cplusplus
extern "C" {
#endif
    int      EXPENTRY OsHangup(systag_t, errpt_t);
    Int16    EXPENTRY OsAbtHangup(systag_t, errpt_t); /* DR 96390*/
    char *   EXPENTRY OsGetCOPMOSIosVersion(void);     /* CLAC-32071, 33175 */
    char *   EXPENTRY OsGetCOPMOSIProtocol(void);      /* CLAC-32071, 33175 */
    int      EXPENTRY OsRecv(systag_t, UInt32, storid_t, UInt32, errpt_t);
    int      EXPENTRY OsReset(errpt_t);
    int      EXPENTRY OsSend(systag_t, UInt32, storid_t, UInt32, errpt_t);
    void              mosi_fini();  /* CLAC-29436 */
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* WIN32 */


#ifdef WIN32 /* DR47427 *//* DR68511 *//* DR66712 */
char * EXPENTRY OsGetCOPOsEncryptVersion(void);
#endif

/************************************************************/
/*          Following are MOSI routines in OSERR.C          */
/************************************************************/

#ifdef WIN32 /* DR47427 *//* DR68511 --> */
Int32  EXPENTRY WCGetPath(char *, char *, char *);
void   EXPENTRY OsGetErr(Int32, char *, errpt_t);
char  *EXPENTRY OsGetOSERRVersion(void);     /* CLAC-32071, 33175 */
#else /* WIN32 */
#ifdef __cplusplus
extern "C" {
#endif
    void  EXPENTRY OsGetErr(Int32, char *, errpt_t);
    char *EXPENTRY OsGetOSERRVersion(void);  /* CLAC-32071, 33175 */
    Int32 EXPENTRY GetPath(char *, char *, char *);
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* WIN32 */

/* <-- DR68511 */

/***************************************************************/
/*                                                             */
/*    ALLOCFAIL - return code define for OsAlloc               */
/*                                                             */
/***************************************************************/

#define ALLOCFAIL NULL                /* DR68511, CLIWS-6938 */

#ifdef __cplusplus                    /* DR45724-> */
extern "C" {
#endif                                  /* <-DR45724 */

    char * EXPENTRY OsGetCOPMTDPVersion(void);  /* CLAC-32071 */
    char * EXPENTRY OsGetCOPTDGSSVersion(void); /* DR87475 */
    int    EXPENTRY OsGetTdWalletVersion(cli_buffer_t, unsigned char,
                    const char *); /* CLAC-663 */
    void   EXPENTRY OsReleaseCLIBuffer(cli_buffer_t);   /* CLAC-663 */

#ifdef WIN32
    int     OsSemInit(int nsem);
    void    OsSemDeInit(void);
    sema_t  *OsAllocSem(void);
    sema_t  *OsSemCreate(int initval);
    int     OsSemGetval(sema_t *sem);     /* 04.01.00.02, DR 38077 */
    Int16   OsSemWait(sema_t *sem, errpt_t error, Int32 iWaitTime);
    Int16   OsSemSignal(sema_t *sem, errpt_t error);
    int     OsSemOp(sema_t *sem, int value);
    int     OsSemrm(sema_t *sem);
    OsLock_t *OsAllocLock(void);
    void    OsFreeLock(OsLock_t *lockp);
    int     OsLock(OsLock_t *lockp, errpt_t error);
    int     OsUnlock(OsLock_t *lockp, errpt_t error);
    int     OsGetPid(void);
#endif

#ifdef __cplusplus                   /* DR45724-> */
}
#endif                                /* <-DR45724 */


/***************************************************************/
/*                                                             */
/*     END of   MOSIIF.H - include file for mosi library       */
/*                                                             */
/***************************************************************/
#endif /* MOSIIF_H */
