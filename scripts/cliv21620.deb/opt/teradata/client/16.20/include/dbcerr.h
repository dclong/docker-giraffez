#ifndef DBCERR_H
#define DBCERR_H
#define DBCERR_H_REV "15.10.00.00"
/*******************************************************************************
 *
 *
 *  WARNING: Because dbcerr.h is shared and is used as a header
 *           file for mainframe SAS/C compiles under VM/CMS, the logical
 *           record length (i.e., line length) must not exceed 80
 *           characters.
 *-----------------------------------------------------------------------------*
 *                   <-- ( 8 0    c h a r a c t e r s) -->
 *******************************************************************************
 *
 *  dbcerr.h - DBC error code include file           15.10.00.00
 *    This include file specifies the Teradata error codes to
 *    be tested for retry conditions in the framer utility
 *
 *
 *     History:       F.1  87Mar19 DAA  DR 11856 87Mar19 Coded
 *                    F.2  87Nov15 SCT  DR 10471 Narrowed to
 *                         <= 65 columns
 *                    F.3  88Jan28 WHY  DR 11926 (MR# fe87-18102a0)
 *                  G0_00  88Jul25  SN  Created for Release G.0
 *                  H0_01  93Feb19 SNT  Created for Release H.0
 *                                      DCR 6536 Password expiration
 *                                      DCR 6434 Error Handling.
 *    H3_00 95Sep13  TH4  DR34047  Added the #ifndef XXXX #define XXXX.
 *    04.00.00.01 TH4 96Jul12 DR36785 Version number change.
 *    05.00.00.00 MDV 97Jul29 DR39844 Added more error codes.
 *                MDV 97Aug29 DR40418 Added the error code 3534.
 *    04.08.00.01 ASG 04Mar02 DR85431 universalize headers
 *    04.08.01.00 ASG 05Apr11 DR92783 Added more error codes.
 *    04.08.01.01 mg180007 2005Apr21 DR93472 added header revision info
 *    04.08.02.00 bh185000 2006Jan12 DR95384 added code 3231 and 3319
 *                                   DR100326 added code 8024 and 8091
 *    04.08.02.01 ASG      2006Feb14 DR102061 reconfig for 80-byte lines
 *    12.00.00.00 fs185009 2006Nov29 DR108852 version change to 12.0.x
 *    13.10.00.00 kl185018 2009Jun23 DR133468 version change to 13.10.x
 *    15.10.00.00 mg180007 2014Apr28 CLAC-32368 version update
 *
 *     Notes:         Please keep lines <= 65 characters long
 *                    Please avoid using tabs
 *
 ***************************************************************/
/**this*line*is*65*characters*long******************************/
 
#define  ErrCLIBadPlist      1
#define  ErrCLIParmCnt       2
#define  ErrCLIBadRCB        3
#define  ErrCLIBadICB        4
#define  ErrCLIBadSPB        5
#define  ErrCLIBadDestICB    6
#define  ErrCLIBadDestRCB    7
#define  ErrCLIFreeRCB       8
#define  ErrCLIBadDBCA       9
#define  ErrCLIECBBusy      10
#define  ErrCLIBadCSet      530
 
 
#define  ErrTOSRead         2123
#define  ErrAMPReadError    2538
#define  ErrAMPEndOfRange   2541
#define  ErrMLDna           2580   /*DR39844*/
#define  ErrAMPLokDeadlock  2631
#define  ErrAllAmpsLogged   2632
#define  ErrAmpTooManyLoad  2633  /* DR100326 */
#define  ErrAMPTransLimit   2639
#define  ErrAMPSChngTbl     2641
#define  ErrAMPSNoRoom      2644
#define  ErrAMPStatusRstr   2654
#define  ErrStat            2667   /*DR39844*/
#define  ErrAMPSRow2Long    2805
#define  ErrAMPRstMod       2809
#define  ErrAMPInvRR        2815
#define  ErrAMPDmpInvLok    2818
#define  ErrAMPNotFound     2825
#define  ErrAMPComplete     2826
#define  ErrAMPRollBckUsr   2827
#define  ErrAMPRollBackRcv  2828
#define  ErrAMPDrpUSI       2830
#define  ErrAMPInv2Indx     2835
#define  ErrAMPDmpBlkLd     2837
#define  ErrAMPDmpUnHsh     2838
#define  ErrAMPRowsDisc     2840
#define  ErrAMPSNoRoomA     2843
#define  ErrAMPDmpRcvAbt    2866
#define  ErrAMPDmpBadPJ     2868
#define  ErrAMPDNoDual      2920
#define  ErrAMPNoSavJnl     2921
#define  ErrAMPJnlNoRoom    2926
#define  ErrAMPKiller       2930   /* DR85431 */
#define  ErrAMPLokTblFull   2971
#define  ErrAMPNoTblHdr     2972
#define  ErrSesNotFound     3000
#define  ErrSesLoggedOn     3001
#define  ErrSesBadAcct      3002
#define  ErrSesBadPass      3003
#define  ErrSesBadUser      3004
#define  ErrSesBadSessNo    3005
#define  ErrSesLogDisab     3006
#define  ErrSesMaxSess      3007
#define  ErrSesBadPart      3008
#define  ErrSesBadScope     3009
#define  ErrSesBadStart     3010
#define  ErrSesWrongPart    3011
#define  ErrSesMissSes      3012
#define  ErrSesInvHostId    3013
#define  ErrSesNoUser       3014
#define  ErrSesNoPass       3015
#define  ErrSesLongName     3016
#define  ErrSesNoTbls       3017
#define  ErrSesBadRAR       3018
#define  ErrSesOldIsThis    3019
#define  ErrSesNotLast      3020
#define  ErrSesBadGSN       3021
#define  ErrSesBadRsp       3022
#define  ErrSesBadStr       3023
#define  ErrSesToManyUtil   3024
#define  ErrSesNeedStart    3025
#define  ErrSesLgnRevoked   3026
#define  ErrSesBadMsg       3027
#define  ErrSesNoThrds      3028
#define  ErrSesLSNNotFound  3029
#define  ErrSesNotIdle      3030
#define  ErrSesPwExpired    3032
#define  ErrDISTimeout      3111
#define  ErrDISMsgOFlow     3116
#define  ErrDISCBNotFound   3119
#define  ErrDISDBCRcv       3120
#define  ErrConRDDLchange   3231    /* DR95384 */
#define  ErrTDWMctlTimeout  3319    /* DR95384 */
#define  ErrTEQAcRViol1     3523
#define  ErrTEQAcRViol2     3524
#define  ErrTEQIndxExist    3534    /*DR40418*/
#define  ErrTEQNoPJrnl      3566
#define  ErrTEQBadRestDBC   3596
#define  ErrTEQDBChanged    3598
#define  ErrTEQTabChanged   3603
#define  ErrTEQIFPDie       3610    /* DR85431 */
#define  ErrTEQDmpRstNoT    3613
#define  ErrTEQJNoExist     3656
#define  ErrTEQNoRecvy      3658
#define  ErrTEQColms        3666    /*DR39844*/
#define  ErrTEQReqLength    3705
#define  ErrTEQNameTrunc    3737
#define  ErrTEQNoStartup    3747
#define  ErrTEQDbNoExist    3802
#define  ErrTEQTExists      3803
#define  ErrTEQVExists      3804
#define  ErrTEQMExists      3805
#define  ErrTEQTVNoExist    3807
#define  ErrTEQMNoExist     3824
#define  ErrTEQMBJTable     3873
#define  ErrTEQTMBNoFlBk    3877
#define  ErrTEQDBCCrash     3897
#define  ErrTEQNotFound     3916
#define  ErrRSGAbort        6699  /* DR92783 */
#define  ErrInvalidTimeStmp 6760  /* DR95384 */
#define  ErrOldInvalidTStmp 7451  /* DR95384 */
#define  ErrGTWNoSession    8018  /* DR92783 */
#define  ErrGtwNoSessAvail  8024  /* DR100326 */
#define  ErrGTWUserOops     8085  /* DR92783 */
 
 
 
#endif /* DBCERR_H */
